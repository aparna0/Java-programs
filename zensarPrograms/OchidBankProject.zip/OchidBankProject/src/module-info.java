module OchidBankProject {
	requires java.sql;
	requires org.junit.jupiter.api;
	
}