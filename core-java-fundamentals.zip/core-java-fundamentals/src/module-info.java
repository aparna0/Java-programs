module corejavafundamentals {
	requires java.sql;
}